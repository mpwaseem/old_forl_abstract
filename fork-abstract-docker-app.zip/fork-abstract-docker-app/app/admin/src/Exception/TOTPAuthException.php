<?php
declare(strict_types=1);

namespace App\Admin\Exception;

/**
 * Class TOTPAuthException
 * @package App\Admin\Exception
 */
class TOTPAuthException extends \Exception
{
}
