<?php
declare(strict_types=1);

namespace App\API;

use App\Common\Kernel\AbstractHttpApp;

/**
 * Class APIService
 * @package App\API
 */
class APIService extends AbstractHttpApp
{
}
