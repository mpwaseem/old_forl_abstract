<?php
declare(strict_types=1);

namespace App\Common\Packages\ReCaptcha;

/**
 * Class ReCaptchaException
 * @package App\Common\Packages\ReCaptcha
 */
class ReCaptchaException extends \Exception
{
}
