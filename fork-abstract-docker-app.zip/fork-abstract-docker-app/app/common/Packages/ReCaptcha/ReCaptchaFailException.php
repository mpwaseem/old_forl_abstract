<?php
declare(strict_types=1);

namespace App\Common\Packages\ReCaptcha;

/**
 * Class ReCaptchaFailException
 * @package App\Common\Packages\ReCaptcha
 */
class ReCaptchaFailException extends ReCaptchaException
{
}
