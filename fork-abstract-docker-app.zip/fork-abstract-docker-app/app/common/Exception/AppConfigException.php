<?php
declare(strict_types=1);

namespace App\Common\Exception;

/**
 * Class AppConfigException
 * @package App\Common\Exception
 */
class AppConfigException extends \Exception
{
}
