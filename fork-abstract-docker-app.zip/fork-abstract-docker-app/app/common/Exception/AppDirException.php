<?php
declare(strict_types=1);

namespace App\Common\Exception;

/**
 * Class AppDirException
 * @package App\Common\Exception
 */
class AppDirException extends \Exception
{
}
