<?php
declare(strict_types=1);

namespace App\Common\Exception;

/**
 * Class AppControllerException
 * @package App\Common\Exception
 */
class AppControllerException extends AppException
{
}
