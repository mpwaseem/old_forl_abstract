<?php
declare(strict_types=1);

namespace App\Common\Exception;

/**
 * Class APIAuthException
 * @package App\Common\Exception
 */
class APIAuthException extends API_Exception
{
}
