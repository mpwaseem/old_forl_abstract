<?php
declare(strict_types=1);

namespace App\Common\Exception;

/**
 * Class ObfuscatedFormsException
 * @package App\Common\Exception
 */
class ObfuscatedFormsException extends AppControllerException
{
}
